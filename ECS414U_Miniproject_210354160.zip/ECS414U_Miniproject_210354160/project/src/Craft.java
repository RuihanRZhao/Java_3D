import Engine.*;
import System.*;

import java.util.ArrayList;

public class Craft {

    public static void main(String[] args) {
        IO.print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
        IO.print("~~             RRRRRR                ZZZZZZZ                      ~~\n");
        IO.print("~~             R     R                    ZZ                      ~~\n");
        IO.print("~~             RRRRRR                  ZZZ                        ~~\n");
        IO.print("~~             R    R                ZZ                           ~~\n");
        IO.print("~~             R     R               ZZZZZZZ                      ~~\n");
        IO.print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
        IO.print("\n");
        IO.print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
        IO.print("~~~~~ Below are the program output! Not the System default! ;) ~~~~~\n");
        IO.print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
        control a=new control(new Map(),1600,900);
    }
}
