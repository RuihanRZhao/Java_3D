package System;

import java.io.File;

public class IO {
    public static void print(int input)   { System.out.print(input);}
    public static void print(char input)  { System.out.print(input);}
    public static void print(String input){ System.out.print(input);}
}

